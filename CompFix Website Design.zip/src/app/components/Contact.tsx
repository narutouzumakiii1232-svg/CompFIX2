import { Send } from "lucide-react";
import { Card } from "./ui/card";

export function Contact() {
  return (
    <section className="py-20 px-4">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-3xl md:text-4xl text-center mb-12 text-[#D4AF37]">
          Контакти
        </h2>
        
        <Card className="p-8 bg-[#1a1a1a] border-[#D4AF37]/30">
          <div className="text-center mb-8">
            <h3 className="text-2xl mb-4 text-[#D4AF37]">
              Зв'яжіться з нами
            </h3>
            <p className="text-[#D4AF37]/70">
              Ми завжди раді відповісти на ваші запитання та допомогти з вибором
            </p>
          </div>
          
          <div className="flex justify-center">
            <a 
              href="https://t.me/Sombody_em"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-3 px-8 py-5 bg-[#D4AF37]/10 hover:bg-[#D4AF37]/20 border border-[#D4AF37]/30 rounded-lg transition-all duration-300 hover:scale-105 group"
            >
              <Send className="w-7 h-7 text-[#D4AF37] group-hover:translate-x-1 transition-transform" />
              <div className="text-left">
                <div className="text-xs text-[#D4AF37]/60 mb-1">Telegram</div>
                <div className="text-xl text-[#D4AF37]">@Sombody_em</div>
              </div>
            </a>
          </div>
          
          <div className="mt-8 text-center">
            <p className="text-sm text-[#D4AF37]/50">
              Працюємо щодня з 9:00 до 21:00
            </p>
          </div>
        </Card>
      </div>
    </section>
  );
}