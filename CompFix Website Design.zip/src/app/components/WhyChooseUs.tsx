import { Award, Users, Target, Clock } from "lucide-react";

const features = [
  {
    icon: Award,
    title: "Досвід",
    description: "Багаторічний досвід роботи з різними конфігураціями комп'ютерів"
  },
  {
    icon: Users,
    title: "Індивідуальний підхід",
    description: "Враховуємо всі ваші побажання та потреби"
  },
  {
    icon: Target,
    title: "Точність",
    description: "Акуратна робота з деталями та кабель-менеджмент"
  },
  {
    icon: Clock,
    title: "Швидкість",
    description: "Оперативне виконання робіт в обумовлені терміни"
  }
];

export function WhyChooseUs() {
  return (
    <section className="py-20 px-4 bg-gradient-to-b from-transparent via-[#D4AF37]/5 to-transparent">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-3xl md:text-4xl text-center mb-12 text-[#D4AF37]">
          Чому обирають нас
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <div 
                key={index}
                className="text-center p-6 rounded-lg bg-[#1a1a1a]/50 border border-[#D4AF37]/10 hover:border-[#D4AF37]/30 transition-all duration-300"
              >
                <div className="inline-flex items-center justify-center w-16 h-16 bg-[#D4AF37]/10 rounded-full mb-4">
                  <Icon className="w-8 h-8 text-[#D4AF37]" />
                </div>
                <h3 className="text-xl mb-2 text-[#D4AF37]">
                  {feature.title}
                </h3>
                <p className="text-sm text-[#D4AF37]/70">
                  {feature.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
