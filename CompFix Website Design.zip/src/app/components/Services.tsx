import { Cpu, Wrench, Settings, ShieldCheck } from "lucide-react";
import { Card } from "./ui/card";

const services = [
  {
    icon: Cpu,
    title: "Збірка ПК",
    description: "Професійна збірка комп'ютерів з ваших комплектуючих. Підбір оптимальних компонентів під ваші потреби та бюджет."
  },
  {
    icon: Wrench,
    title: "Ремонт та обслуговування",
    description: "Діагностика та усунення несправностей. Чистка від пилу, заміна термопасти, апгрейд комплектуючих."
  },
  {
    icon: Settings,
    title: "Налаштування системи",
    description: "Встановлення та налаштування операційної системи, драйверів та програмного забезпечення."
  },
  {
    icon: ShieldCheck,
    title: "Гарантія якості",
    description: "Тестування стабільності системи. Гарантія на всі роботи. Консультації та технічна підтримка."
  }
];

export function Services() {
  return (
    <section className="py-20 px-4">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-3xl md:text-4xl text-center mb-12 text-[#D4AF37]">
          Наші послуги
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <Card 
                key={index} 
                className="p-6 bg-[#1a1a1a] border-[#D4AF37]/20 hover:border-[#D4AF37]/40 transition-all duration-300 hover:shadow-lg hover:shadow-[#D4AF37]/10"
              >
                <div className="flex items-start gap-4">
                  <div className="bg-[#D4AF37]/10 p-3 rounded-lg">
                    <Icon className="w-8 h-8 text-[#D4AF37]" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl mb-2 text-[#D4AF37]">
                      {service.title}
                    </h3>
                    <p className="text-[#D4AF37]/70">
                      {service.description}
                    </p>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}
