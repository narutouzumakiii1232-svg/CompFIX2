import logo from "figma:asset/13fdb4ceb131ae832e7fe4400ffba869f6634815.png";

export function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center px-4 py-20">
      <div className="absolute inset-0 bg-gradient-to-b from-[#D4AF37]/10 via-transparent to-transparent" />
      
      <div className="max-w-4xl mx-auto text-center relative z-10">
        <div className="mb-8 flex justify-center">
          <img 
            src={logo} 
            alt="CompFix Logo" 
            className="w-64 h-64 md:w-80 md:h-80 object-contain"
          />
        </div>
        
        <h1 className="text-4xl md:text-6xl mb-6 text-[#D4AF37]">
          CompFix
        </h1>
        
        <p className="text-xl md:text-2xl mb-8 text-[#D4AF37]/80">
          Професійна збірка та обслуговування комп'ютерів
        </p>
        
        <p className="text-lg text-[#D4AF37]/60 max-w-2xl mx-auto">
          Ми спеціалізуємось на складанні комп'ютерів з ваших комплектуючих та їх професійному обслуговуванні
        </p>
      </div>
    </section>
  );
}
