import { Hero } from "./components/Hero";
import { Services } from "./components/Services";
import { WhyChooseUs } from "./components/WhyChooseUs";
import { Contact } from "./components/Contact";

export default function App() {
  return (
    <div className="min-h-screen bg-black">
      <Hero />
      <Services />
      <WhyChooseUs />
      <Contact />
      
      <footer className="py-8 px-4 border-t border-[#D4AF37]/20">
        <div className="max-w-6xl mx-auto text-center text-[#D4AF37]/50 text-sm">
          <p>© 2024 CompFix. Всі права захищені.</p>
        </div>
      </footer>
    </div>
  );
}
